// This class is for every element of the bricks; 
// Something like pixel, but bigger.

public class BoxElement {

}
